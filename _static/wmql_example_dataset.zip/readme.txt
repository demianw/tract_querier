WMQL example dataset
====================


Dataset to use as an example for the white matter query language [1]. Tracts
obtained from the IIT atlas version 2 (https://www.nitrc.org/projects/iit/)
[2]. 

To run the example scripts, please use these commandlines:
tract_querier -a MNI152_wmparc_1mm_small.nii.gz -t IIT2mean.trk -q wmql_1_cst.qry -o result1

tract_querier -a MNI152_wmparc_1mm_small.nii.gz -t IIT2mean.trk -q wmql_2_uf.qry -o result2

tract_querier -a MNI152_wmparc_1mm_small.nii.gz -t IIT2mean.trk -q wmql_3_commissural.qry -o result3




[1] The white matter query language: a novel approach for describing human white matter anatomy
Demian Wassermann , Nikos Makris, Yogesh Rathi, Martha Shenton, Ron Kikinis, Marek Kubicki, Carl-Fredrik Westin
10.1007/s00429-015-1179-4

[2] Varentsova A, Zhang S, Arfanakis K. Development of a High Angular Resolution Diffusion Imaging Human Brain Template. NeuroImage 2014;91:177-186
